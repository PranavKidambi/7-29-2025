import java.sql.*;


public class Copy {

    public Connection Newc(String dbname, String user, String password){
        Connection conn= null;
        try{
            Class.forName("org.postgresql.Driver");
            conn= DriverManager.getConnection("jdbc:postgresql://localhost:5432:/"+dbname,user,password);

            if(conn!=null){
                System.out.println("Successful");
            }
            else{
                System.out.println("Fail");
            }
        }
        catch(Exception e) {
            System.out.println(e);
        }

    return conn;
    }



}

