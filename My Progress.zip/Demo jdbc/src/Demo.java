import java.sql.*;
public class Demo {

    public Connection Dbc(String dbname, String user, String password) {
        Connection con = null;
        try {
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/" + dbname, user, password);
            if (con != null) {
                System.out.println("Connection successful");
            }
            else {
                System.out.println("Connection failed");
            }
        }
        catch (Exception e) {
            System.out.println(e);
        }
        return con;
    }

    public void create_table(Connection con, String TableName) {
        Statement st = null;
        try {
            String query = "CREATE TABLE " + TableName + "(emp_id SERIAL, name varchar(20), address varchar(50), primary key (emp_id))";
            st = con.createStatement();
            st.executeUpdate(query);
            System.out.println("Table created");
        }
        catch (Exception e) {
            System.out.println(e);
        }
        finally {
            try {
                if (st!= null) {
                    st.close();
                }
            } catch(Exception ex){
                System.out.println(ex);
            }
        }
    }

    public void insert_data(Connection con, String TableName, String name, String address) {
        PreparedStatement pst = null;
        try {
            String query = "INSERT INTO " + TableName + "(name,address) VALUES (?, ?)";
            pst = con.prepareStatement(query);
            pst.setString(1, name);
            pst.setString(2, address);
            pst.executeUpdate();
            System.out.println("Rows Inserted");
        }
        catch (Exception e) {
            System.out.println(e);
        }
        finally {
            try{
                if (pst != null) {
                    pst.close();
                }
            }
            catch(Exception ex){
                System.out.println(ex);
            }
        }
    }

    public void read_data(Connection con, String TableName) {
        Statement st = null;
        ResultSet rs = null;
        try {
            String query = "SELECT * FROM " + TableName + " ORDER BY emp_id";
            st = con.createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                System.out.print(rs.getInt("emp_id") + " ");
                System.out.print(rs.getString("name") + " ");
                System.out.println(rs.getString("address"));
            }
        }
        catch (Exception e) {
            System.out.println(e);
        }
        finally {
            try{
                if (rs!= null){
                    rs.close();
                }
            }
            catch(Exception ex){
                System.out.println(ex);
            }
            try{
                if (st != null){
                    st.close();
                }
            }
            catch(Exception ex) {
                System.out.println(ex);
            }
        }
    }

    public void update_name(Connection con) {
        PreparedStatement pst = null;
        String TableName = "Employee";
        String Old_name = "Praveen";
        String New_name = "Bhaskar";
        try {
            String query = "UPDATE " + TableName + " SET name = ? WHERE name = ?";
            pst = con.prepareStatement(query);
            pst.setString(1, New_name);
            pst.setString(2, Old_name);
            pst.executeUpdate();
            System.out.println("Update Successful");
        }
        catch (Exception e) {
            System.out.println(e);
        }
        finally {
            try{
                if (pst != null) {
                    pst.close();
                }
            }
            catch (Exception ex) {
                System.out.println(ex);
            }
        }
    }

    public void Search(Connection con, String TableName, String name) {
        PreparedStatement pst = null;
        ResultSet rs = null;
        try {
            String query = "SELECT * FROM " + TableName + " WHERE name = ?";
            pst = con.prepareStatement(query);
            pst.setString(1, name);
            rs = pst.executeQuery();
            while (rs.next()) {
                System.out.print(rs.getInt("emp_id") + " ");
                System.out.print(rs.getString("name") + " ");
                System.out.println(rs.getString("address"));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        finally {
            try {
                if (rs != null){
                    rs.close();
                }
            }
            catch (Exception ex) {
                System.out.println(ex);
            }
            try{
                if(pst != null){
                    pst.close();
                }
            }
            catch (Exception ex){
             System.out.println(ex);
            }
        }
    }

    public void delete_row(Connection con, String TableName, int Emp_id) {
        PreparedStatement pst = null;
        try {
            String query = "DELETE FROM " + TableName + " WHERE emp_id = ?";
            pst = con.prepareStatement(query);
            pst.setInt(1, Emp_id);
            pst.executeUpdate();
            System.out.println("Row deleted");
        }
        catch (Exception e) {
            System.out.println(e);
        }
        finally {
            try{
                if (pst != null){
                    pst.close();
                }
            }
            catch (Exception ex){
                System.out.println(ex);
            }
        }
    }

    public void Insertion(Connection con, String TableName, String name, String address) {
        CallableStatement cs = null;
        try {
            String query = "CALL insert_employee(?, ?)";
            cs = con.prepareCall(query);
            cs.setString(1, name);
            cs.setString(2, address);
            cs.execute();
            System.out.println("Procedure Executed");
        }
        catch(Exception e) {
            System.out.println(e);
        }
        finally
        {
            try {
                if (cs!= null){
                    cs.close();
                }
            }
            catch(Exception ex){
                System.out.println(ex);
            }
        }
    }
}
