import java.sql.*;

public class Main {
    public static void main(String[] args) {
        Demo dd = new Demo();
        Connection con= dd.Dbc("Pranav", "postgres", "1234");
        //dd.create_table(con,"Employee");
        //dd.insert_data(con,"Employee","Praveen","USA");
        //dd.read_data(con,"Employee");
        //dd.update_name(con,"Employee","Pranav","KTS_Pranav");
        //dd.update_name(con);
        //dd.Search(con,"Employee","Tez");
        //dd.delete_row(con,"Employee",3);
        dd.Insertion(con,"Employee","Kidambi","India");


    }
}