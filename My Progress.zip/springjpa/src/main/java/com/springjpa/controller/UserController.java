package com.springjpa.controller;
import com.springjpa.model.User;
import com.springjpa.service.UserService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    private final UserService userService;
    public UserController(UserService userService) {
        this.userService = userService;
    }
    @PostMapping
    public User createUser(@Valid @RequestBody User user) {
        return userService.createUser(user);
    }
    @GetMapping
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }
    @GetMapping("/{id}")
    public User getUserById(@PathVariable int id) {
        return userService.getUserById(id);
    }
    @GetMapping("/name/{name}")
    public User getUserByName(@PathVariable String name) {
        return userService.getUserByName(name);
    }
    @GetMapping("/email/{email}")
    public User getUserByEmail(@PathVariable String email) {
        return userService.getUserByEmail(email);
    }
    @GetMapping("/phone/{phone}")
    public User getUserByPhone(@PathVariable String phone) {
        return userService.getUserByPhone(phone);
    }
    @GetMapping("birthday/{birthday}")
    public User getUserByBirthday(@PathVariable LocalDate birthday) {
        return userService.getByBirthday(birthday);
    }
    @GetMapping("/active/{active}")
    public List<User> getUsersByActive(@PathVariable boolean active) {
        return userService.getUsersByActive(active);
    }
    @GetMapping("/salary/{salary}")
    public User getUserBySalary(@PathVariable double salary) {
        return userService.getBySalary(salary);
    }
    @PutMapping("/{id}")
    public User updateUser(@Valid @PathVariable int id, @RequestBody User user) {
        return userService.updateUser(id, user);
    }
    @DeleteMapping("/{id}")
    public boolean deleteUser(@PathVariable int id) {
        return userService.deleteUser(id);
    }
}
