package com.springjpa.model;
import jakarta.validation.constraints.*;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String name;
    @Email(message = "Invalid")
    @Pattern(regexp = ".*@gmail\\.com$", message = "Email must end with @gmail.com")
    private String email;
    @Column(length = 10)
    @Pattern(regexp = "^[0-9]{10}$", message = "must be 10 digits")
    private String phone;
    @Past(message = "must be in past")
    private LocalDate birthday;
    private boolean active;
    @DecimalMin(value = "0.0", inclusive = false, message = "invalid")
    private double salary;

    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "address_id")
    private Address address;

    public User() {
    }

    public User(int id, Address address, double salary, boolean active, LocalDate birthday, String phone, String email, String name) {
        this.id = id;
        this.address = address;
        this.salary = salary;
        this.active = active;
        this.birthday = birthday;
        this.phone = phone;
        this.email = email;
        this.name = name;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public double getSalary() {
        return salary;
    }
    public void setSalary(double salary) {
        this.salary = salary;
    }
    public boolean isActive() {
        return active;
    }
    public void setActive(boolean active) {
        this.active = active;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public LocalDate getBirthday() {
        return birthday;
    }
    public void setBirthday(LocalDate birthday) {
        this.birthday = birthday;
    }
    public Address getAddress() {
        return address;
    }
    public void setAddress(Address address) {
        this.address = address;
    }
}
