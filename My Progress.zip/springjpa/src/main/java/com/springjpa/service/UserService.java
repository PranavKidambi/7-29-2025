package com.springjpa.service;
import com.springjpa.model.User;
import com.springjpa.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;
    public UserService(UserRepository userRepository) {

        this.userRepository = userRepository;
    }
    public User createUser(User user) {
        return userRepository.save(user);
    }
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
    public User getUserById(int id) {
        return userRepository.findById(id).orElse(null);
    }
    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email).orElse(null);
    }
    public User getUserByName(String name) {
        return userRepository.findByName(name).orElse(null);
    }
    public User getUserByPhone(String phone) {
        return userRepository.findByPhone(phone).orElse(null);
    }
    public List<User> getUsersByActive(boolean active) {
        return userRepository.findUsersByActive(active);
    }
    public User getBySalary(double salary) {
        return userRepository.findBySalary(salary).orElse(null);
    }
    public User getByBirthday(LocalDate birthday) {
        return userRepository.findByBirthday(birthday).orElse(null);
    }
    public User updateUser(int id, User updatedUser) {
        Optional<User> optionalUser = userRepository.findById(id);
        if (optionalUser.isPresent()) {
            User existingUser = optionalUser.get();
            existingUser.setName(updatedUser.getName());
            existingUser.setEmail(updatedUser.getEmail());
            existingUser.setPhone(updatedUser.getPhone());
            existingUser.setBirthday(updatedUser.getBirthday());
            existingUser.setSalary(updatedUser.getSalary());
            existingUser.setActive(updatedUser.isActive());

            if (updatedUser.getAddress() != null) {
                existingUser.setAddress(updatedUser.getAddress());
            }

            return userRepository.save(existingUser);
        }
        return null;
    }

    public boolean deleteUser(int id) {
        if (userRepository.existsById(id)) {
            userRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
