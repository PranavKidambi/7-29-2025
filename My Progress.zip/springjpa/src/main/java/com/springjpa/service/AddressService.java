package com.springjpa.service;
import com.springjpa.model.Address;
import com.springjpa.repository.AddressRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class AddressService {
    private final AddressRepository addressRepository;
    public AddressService(AddressRepository addressRepository) {
        this.addressRepository = addressRepository;
    }
    public Address createAddress(Address address) {
        return addressRepository.save(address);
    }
    public List<Address> getAllAddress() {
        return addressRepository.findAll();
    }
    public Address getAddressById(int id) {
        return addressRepository.findById(id).get();
    }
    public Address updateAddress(int id, Address newAddr) {
        Address addr = getAddressById(id);
        addr.setCity(newAddr.getCity());
        addr.setState(newAddr.getState());
        addr.setZipcode(newAddr.getZipcode());
        return addressRepository.save(addr);
    }
    public void deleteAddress(int id) {
        addressRepository.deleteById(id);
    }


}