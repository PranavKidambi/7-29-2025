package com.springjdbc.service;
import com.springjdbc.model.User;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Service
public class UserService {

    private final JdbcTemplate jdbcTemplate;
    public UserService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
    private RowMapper<User> userRowMapper = new RowMapper<>() {
        public User mapRow(ResultSet rs, int rowNum) throws SQLException {
            return new User(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("email")
            );
        }
    };
    public User createUser(User user) {
        String sql = "INSERT INTO users (name, email) VALUES (?, ?) RETURNING id";
        int id = jdbcTemplate.queryForObject(sql, Integer.class, user.getName(), user.getEmail());
        user.setId(id);
        return user;
    }
    public List<User> getAllUsers() {
        return jdbcTemplate.query("SELECT * FROM users", userRowMapper);
    }
    public User getUserById(int id) {
        String sql = "SELECT * FROM users WHERE id = ?";
        List<User> users = jdbcTemplate.query(sql, userRowMapper, id);
        return users.isEmpty() ? null : users.get(0);
    }
    public User updateUser(int id, User updatedUser) {
        String sql = "UPDATE users SET name = ?, email = ? WHERE id = ?";
        int rows = jdbcTemplate.update(sql, updatedUser.getName(), updatedUser.getEmail(), id);
        return rows > 0 ? getUserById(id) : null;
    }
    public boolean deleteUser(int id) {
        String sql = "DELETE FROM users WHERE id = ?";
        return jdbcTemplate.update(sql, id) > 0;
    }
}
