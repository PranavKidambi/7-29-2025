package com.basicsb.service;
import com.basicsb.model.User;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class UserService {
    private final Map<Integer, User> userMap = new HashMap<>();
    private int currentId = 1;
    public User createUser(User user) {
        user.setId(currentId++);
        userMap.put(user.getId(), user);
        return user;
    }
    public List<User> getAllUsers() {
        return new ArrayList<>(userMap.values());
    }
    public User getUserById(int id) {
        return userMap.get(id);
    }
    public User updateUser(int id, User updatedUser) {
        User existingUser = userMap.get(id);
        if (existingUser != null) {
            existingUser.setName(updatedUser.getName());
            existingUser.setEmail(updatedUser.getEmail());
            return existingUser;
        }
        return null;
    }
    public boolean deleteUser(int id) {
        return userMap.remove(id) != null;
    }
}
