package com.basicsb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasicsbApplication {

    public static void main(String[] args) {
        SpringApplication.run(BasicsbApplication.class, args);
    }

}
