package com.basicsb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasicsbApplicationTests {

    @Test
    void contextLoads() {
    }

}
